package com.example.to_do_project;

import android.content.DialogInterface;

public interface DialogCloseListener {

    public void handleDialogClose(DialogInterface dialog);
}
